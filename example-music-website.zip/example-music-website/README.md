# example-music-website

This is a example of a music album website like monstercat